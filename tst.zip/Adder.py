#Add words that can be present inside not banned words
adder=[
'xx',
'sex',
'semen',
'tit',
'spic',
'amm',
'paki',
'bitcoin',
'osur',
'anan',
'anal',
'cum',
'xxx'
] 
